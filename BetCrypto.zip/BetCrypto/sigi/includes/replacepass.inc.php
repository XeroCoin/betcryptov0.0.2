<?php

if (isset($_POST["resetpwdsub"])) {
  $selector = $_POST['selector'];
  $valid = $_POST['validator'];
  $pass= $_POST['pwd'];
  $rptpass = $_POST['pwd-rpt'];

  if (empty($pass) || empty($rptpass)) {
    header("Location: ../create-new-pass.php?newpwd=empty");
    exit();
  }
elseif ($pass != $rptpass) {
  header("Location: ../create-new-pass.php?newpwd=pwdnotsame");
  exit();
}
$currentDate = date("U");

require 'dbh.inc.php';

$sql = "SELECT * FROM resetpass WHERE resetSelect=? AND resetExp >= ? ";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt, $sql)) {
  echo "error1";
  exit();
}
else {
  mysqli_stmt_bind_param($stmt, "ss", $selector, $currentDate);
  mysqli_stmt_execute($stmt);

  $result = mysqli_stmt_get_result($stmt);
  if (!$row = mysqli_fetch_assoc($result)) {
    echo "please resubmit request1";
    exit();
  }
  else {
    $tkbin = hex2bin($valid);
    $tknck = password_verify($tkbin, $row["resetToken"]);
    if ($tknck === false) {
      echo "please resubmit request2";
      exit();
    }
    elseif ($tknck === true) {
      $tokenEmail = $row["resetEmail"];
      $sql = "SELECT * FROM gamblers WHERE gamblerEmail=?";
      $stmt = mysqli_stmt_init($conn);
      if (!mysqli_stmt_prepare($stmt, $sql)) {
        echo "error2";
        exit();
      }
      else {
        mysqli_stmt_bind_param($stmt, "s", $tokenEmail);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if (!$row = mysqli_fetch_assoc($result)) {
          echo "error3";
          exit();
        }
        else {
          $sql = "UPDATE gamblers SET GamblerPwd=? WHERE gamblerEmail=?";
          $stmt = mysqli_stmt_init($conn);
          if (!mysqli_stmt_prepare($stmt, $sql)) {
            echo "error4";
            exit();
          }
          else {
            $newpwHash = password_hash($pass, PASSWORD_DEFAULT);
            mysqli_stmt_bind_param($stmt, "ss", $newpwHash, $tokenEmail);
            mysqli_stmt_execute($stmt);
            $sql = "DELETE FROM resetpass WHERE resetEmail=?";
            $stmt = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($stmt, $sql)) {
              echo "error5";
              exit();
            }
            else{
              mysqli_stmt_bind_param($stmt, "s", $tokenEmail);
              mysqli_stmt_execute($stmt);
              header("Location: ../index.php?newpwd=passwordupdated");
        }
      }
      }
    }
  }
}
}
}

else {
  header("Location ../index.php");
}
