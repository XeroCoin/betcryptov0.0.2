<?php
session_start();
if (isset($_SESSION['userId'])) {
  if (isset($_POST['subSend'])) {
    require 'db2.inc.php';
    $name = $_SESSION['uname'];
    $bname = $_POST['getbet'];
    $ovun = $_POST['getoverunder'];
    $betAmount = $_POST['getamount'];
    $paymentid = $_POST['getpayid'];
    $recaddy = $_POST['walletaddy'];

    $sql = "INSERT INTO usersrecordedbets (betterName, nameOfBet, picked, betAmount, paymentID, userRecAddress) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){

      header('location: /Betcrypto/sigi/register.php?return=sqlreturn');
      exit();
    }
    else {
      mysqli_stmt_bind_param($stmt, "ssssss", $name, $bname, $ovun,$betAmount,$paymentid,$recaddy);
      mysqli_stmt_execute($stmt);

      header('location: /Betcrypto/sigi/index.php?bet=Success!');
    }
  }
  else{
    header('location: /Betcrypto/sigi/recordBet.php?error=getouttahere');
  }
}
else{
  echo "Please Login";
}
