
<?php

$page_title = 'Record Bet';
include 'includes/header.php';
 ?>
 <body>
   <?php include 'includes/navigation.php'; ?>
   <?php
   if (isset($_SESSION['userId'])) {
     echo '<form id="sndBet" action="../sigi/includes/sendbet.inc.php" method="post">
       <div class="form-group jumbotron">
          <div class="" id="allinfo">
            <h2>Please review the following information below</h2>
            <br>
            <br>


            <h6 class="user" name="user" >User: '.$activeUser.'</h6>

            <br>


            <h6>Bet Name:</h6>
            <p class="confirm-content" id="setBet" name="bet"> </p>


            <h6>You have chosen the: </h6>
            <p class="confirm-content" id="o_u" name="ovun"></p>

            <h6>Bet Amount: </h6>
            <p class="confirm-content" id="setAmt" name="amt"></p>


            <h6>Please deposit funds to the following address: </h6>
            <p class="confirm-content" id="depAddy" name="deposit"></p>

            <h6>Please send funds with the following Payment ID: </h6>
            <p class="confirm-content" id="pmtID" name="idPMT"></p>

            <br><br><br>
            <h6>Please enter the address you would your payout sent to:</h6>
            <input type="text" id="payoutAddress" size="55" name="walletaddy" placeholder="Please enter the address you would your payout sent to">
            <br><br><br>


            <input type="hidden" id="namebet" name="getbet" >
            <input type="hidden" id="overunder" name="getoverunder" value="">
            <input type="hidden" id="amountbet" name="getamount" value="">
            <input type="hidden" id="betpayid" name="getpayid" value="">
            <button type="button" id="openmodal" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
            Submit
            </button>
          </div>
       </div>
       <!-- Modal -->
       <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered" role="document">
           <div class="modal-content">
             <div class="modal-header">
               <h5 class="modal-title" id="exampleModalLongTitle">Are you sure you would like to place this bet?</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
               </button>
             </div>
             <div class="modal-body">
               <h6>Disclosures:</h6>
               <br>
               <p class="disclosures">Please note that <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis vel porta lectus. Fusce id massa ac augue consectetur tempor. Duis vel enim sit amet mi rutrum volutpat sit amet quis ante. Curabitur lacinia, lectus at placerat aliquam, justo ante commodo magna, non dictum quam arcu id odio. Morbi at nulla urna. Nulla lobortis dictum velit a dignissim. Suspendisse semper turpis ex, et ultricies felis maximus et. Vestibulum fermentum nibh ac elit iaculis, a aliquam velit viverra.</span></p>
             </div>
             <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               <button type="submit" id="confirm" name="subSend" class="btn btn-success">Confirm</button>
             </div>
           </div>
         </div>
       </div>
     </form>';




   }
   else{
     echo '<div class="container">
         <div class="row">
           <div class="col-lg-12 text-center">
             <h1 class="mt-5">Please <a href="login.php">Log in</a></h1>
             <p class="lead">Or <a href="register.php">Sign Up</a> now to enjoy Bet Crypto</p>
             <ul class="list-unstyled">
               <li>BetCrypto &copy;</li>
               <li>poop</li>
             </ul>
           </div>
         </div>
       </div>';
   }
    ?>


   <script src="vendor/jquery/jquery.min.js"></script>
   <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
   <script src="scripts/sendtodb.js"></script>

   <!-- Menu Toggle Script -->
   <script>
   $("#menu-toggle").click(function(e) {
     e.preventDefault();
     $("#wrapper").toggleClass("toggled");
   });
   </script>


   </body>
 </html>
