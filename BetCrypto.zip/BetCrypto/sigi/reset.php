<?php
$page_title = "Forgot Password";
include 'includes/header.php';
 ?>

<body>
  <?php include 'includes/navigation.php'; ?>
  <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h1 >Reset Your Password</h1>
          <p class="lead">An email will be sent to you with instructions on how to reset your password</p>
          <form class="" action="includes/reset.inc.php" method="post">
            <input type="text" name="email" placeholder="Enter your E-Mail address">
            <button type="submit" name="resetreqsub">Receive new password</button>
          </form>
<?php
  if (isset($_GET["reset"])) {
    if ($_GET["reset"] == "success") {
      echo "check your email";
    }
  }

 ?>
          <ul class="list-unstyled">
            <li>BetCrypto &copy;</li>
            <li>poop</li>
          </ul>
        </div>
      </div>
    </div>
</body>
</html>
